<hr/>
<p>Configurez les droits d&rsquo;acc&egrave;s pour la partie admin:</p>
<ul>
<li>Tout: l&rsquo;admin a acc&egrave;s &agrave; cette page sans restrictions</li>
<li>Lecture: l&rsquo;admin peut voir le contenu des pages, mais ne peut rien changer.  Cette option ne fonctionne que pour les pages "utilisateur", "utilisateurs" et "membres".</li>
<li>Aucun: l&rsquo;admin n&rsquo;a pas d'acc&egrave;s &agrave; cette page</li>
<li>Propri&eacute;taire: l&rsquo;admin a acc&egrave;s &agrave; cette page, mais ne peut voir que les listes dont il est le propri&eacute;taire</li>
</ul>

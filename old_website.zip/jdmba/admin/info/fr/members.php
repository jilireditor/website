<br />En cliquant sur Supprimer, vous supprimerez cette personne uniquement de cette liste

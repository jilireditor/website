<br/>
<p>Obrigado por usar <?php echo NAME?>.<br>Esperamos que voc&ecirc; tenha atingido os seus objetivos.</p>
<p>Agora voc&ecirc; est&aacute; desconectado.</p>
<p>Para se conectar novamente, clique <a href='?page=home'>aqui</a>.</p>


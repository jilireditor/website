<br />Apagar ir&aacute; excluir esta pessoa somente desta lista

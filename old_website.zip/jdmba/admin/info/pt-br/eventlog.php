<p>Esta p&aacute;gina lista os eventos de <?php echo NAME?> e que pode ser interessante analisar.
As entreadas est&atilde;o listadas em ordem cronol&oacute;gica inversa</p>

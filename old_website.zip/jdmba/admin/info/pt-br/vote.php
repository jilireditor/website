

<p><b>Vote no PHPlist</b><br/>
Se voc&ecirc; acha que o PHPlist &eacute; &oacutetimo; e voc&ecirc; gostaria de aconselhar outras pessoas a us&aacute;-lo, por que n&atilde;o votar nele em alguns sites? 
</p>
<p>Se voc&ecirc; encontrar o PHPlist em um site diferente e acha que ele poderia ser inclu&iacute;do aqui, <a href="mailto:phplist2@tincan.co.uk?subject=New Directory">nos envie um email</a></p>
<ul>
<li><b>No freshmeat</b>
<form method="post" action="http://freshmeat.net/rate/store/" target="_vote">
  <input type="hidden" name="project_id" value="7994">
<table cellspacing="3" cellpadding="0" border="0">
  <tr>
    <td valign="middle" width="15%">
  <b>Avalia&ccedil;&atilde;o:</b>
    </td>
  <td valign="top" width="85%">
  <select name="rating" onchange="submit()">

  <option value="">-
      <option value="1">1</option>
      <option value="2">2</option>
      <option value="3">3</option>
      <option value="4">4</option>
      <option value="5">5</option>
      <option value="6">6</option>

      <option value="7">7</option>
      <option value="8">8</option>
      <option value="9">9</option>
      <option value="10" selected>10</option>
    </select>
  <input type="submit" value="set rating">
    </td>
  </tr>
</table>
</form>
</li>
<li><b>No codetransit</b>
<form action="http://www.codetransit.com/index.php" method=post name=rate531 target="_vote"><input type=hidden name=action value=rate><input type=hidden name=id value=531>
          <select name=score size=1 style="font-family: Verdana, Tahoma, Arial, Helvetica; font-size: 10pt; color: #000000" onchange="document.rate531.submit()">
            <option>Select
            <option value="1">Ruim
            <option value="2">M&eacute;dio
            <option value="3">Bom
            <option value="4">Muito bom
            <option value="5" selected>&Oacute;timo
          </select>
  <input type="submit" value="set rating">
          </form> ou escreva um <a href="http://www.codetransit.com/comments/index.php?action=addcommentsform&id=531&title=PHPlist&version=1.8.0" target="_review">Coment&aacute;rio</a>
<br/><br/></li>
<li><b>No PHPWelt</b> (alem&atildeo)
<form action="http://www.phpwelt.de/archiv/arcscript.php" method="post" target="_vote">
<select name="arcwert" class="vote">
<option selected>10
<option>9
<option>8
<option>7
<option>6
<option>5
<option>4
<option>3
<option>2
<option>1
</select>
<input type="submit" value="vote">
<input type="hidden" name="ack_vote" value="TRUE">
<input type="hidden" name="arcid" value="226">
</form>
</li>
<li><b>No scripts.org</b> (alem&atideo)<br/>
<a href="http://www.scripts.org/links.php?op=rate&lid=773&progname=PHPlist" target="_vote">Avalie o PHPlist</a><br/><br/>
</li>
<li><b>No resourceindex</b><br/>
<a href="http://php.resourceindex.com/detail/00074.html" target="_vote">Avalie o PHPlist</a><br/><br/>
</li>
<li><b>No <a href="http://www.hotscripts.com/?RID=9619">Hotscripts</a></b><br/>
<form action="http://www.hotscripts.com/cgi-bin/rate.cgi" method="POST">
<input type=hidden name="ID" value="5015">
<table BORDER="0" CELLSPACING="0" CELLPADDING="2" bgcolor="#CCCC99">
<tr><td><font face="arial,verdana,helvetica" size="2"><b>Cabine de Vota&ccedil;&atilde;o do Visitante: </b></td>
<td><select name="rate" size="1"><option selected>Fa&ccedil;a a sua Avalia&ccedil;&atilde;o</option>
<option value="5" selected>&Oacute;timo!</option><option value="4">Muito Bom</option>
<option value="3">Bom</option><option value="2">M&eacute;dio</option>
<option value="1">Ruim</option></select></td><td>
<input type="submit" value="Rate It!"></td></tr></table></form>
<a href="http://www.hotscripts.com/review/?linkid=5015&returnto=http://www.hotscripts.com/Detailed/5015.html" target="_review">Escreva um Coment&aacute;rio</a><br/><br/>

</li>
<li><b>No Devscripts.com</b>
<form action="http://devscripts.com/vote.php" method="post" name="frmRate" target="_vote">
<input type="hidden" name="strScriptId" value="1465">
    <select name="strRValue" onChange="document.frmRate.submit();">
        <option value="NULL">Avalia&ccedil;&atilde;o</option>
        <option value="10" selected>10</option>

        <option value="9">9</option>
        <option value="8">8</option>
        <option value="7">7</option>
        <option value="6">6</option>
        <option value="5">5</option>
        <option value="4">4</option>

        <option value="3">3</option>
        <option value="2">2</option>
        <option value="1">1</option>
    </select><input type="submit" value="set rating">
</form>
<a href="http://devscripts.com/review.php?sId=1465" target="_review">Escreva um coment&aacute;rio</a><br/><br/>
</li>
<li><b>No webscript.ru</b> (russo)<br/>
<form name="rate" method="post" action="http://webscript.ru/action.php?sid=598201422&action=rate&linkid=22&having=753">
5 <input type="radio" value="5" name="form_rate_radio_vote" checked>
4  <input type="radio" value="4" name="form_rate_radio_vote">
3 <input type="radio" value="3" name="form_rate_radio_vote">
2 <input type="radio" value="2" name="form_rate_radio_vote">
1 <input type="radio" value="1" name="form_rate_radio_vote">
<input type="submit" name="form_rate_button_rate" class="button" value="Rate">
</form>
</li>
<li><b>No PHPindex.com</b> (franc&ecircs)<br/>
<a href="http://www.phpindex.com/annuaire/annuaire_critique.php3?annuaire_critique_annuaire_id=917">Adicionar um coment&aacute;rio</a><br/><br/>
</li>
<li><b>No bigboys</b><br/>
<form method="GET" action="http://www.big-boys.com/php/vote1.asp">
    <select size="1" name="F1">
      <option VALUE="1">1 - Ruim
      <option VALUE="2">2
      <option VALUE="3">3
      <option VALUE="4">4
      <option VALUE="5">5 - M&eacute;dio
      <option VALUE="6">6
      <option VALUE="7">7
      <option VALUE="8">8
      <option VALUE="9">9
      <option VALUE="10" selected>10 - Excelente
      <input Type="Hidden" Name="ID" Value="151">
    </select>
    <input type="submit" value="Vote">
</form>

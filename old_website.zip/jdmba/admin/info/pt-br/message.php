<br /><?php echo PageLink2("messages","Volta para a lista de Mensagens")?>
<br /><a href="#resend">Enviar esta mensagem para uma outra lista</a>

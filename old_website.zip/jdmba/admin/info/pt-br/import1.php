Aqui voc&ecirc; pode adicionar m&uacute;ltiplos emails &agrave;s suas listas. Todos os emails necessitam ter os mesmos atributos, os quais voc&ecirc; pode indicar abaixo.

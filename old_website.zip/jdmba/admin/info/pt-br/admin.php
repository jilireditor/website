<hr/>
<p>Defina as permiss&otildees de visualiza&ccedil&atilde;o das p&aacute;ginas do sistema:</p>
<ul>
<li>Todas: admin tem acesso &agrave;s p&aacute;ginas sem nenhuma restri&ccedil;&atilde;o</li>
<li>Visualizar: admin pode ver o conte&uacutedo das p&aacuteginas, mas sem poder modific&aacute-las. Atualmente s&oacute funciona para p&aacuteginas de "usu&aacute;rio", "usu&aacute;rios" e "membros'.</li>
<li>Nenhuma: admin n&atilde;o pode visualizar esta p&aacute;gina</li>
<li>Administrativa: admin pode visualizar esta p&aacute;gina, mas somente o conte&uacutedo das listas que eles administram</li>
</ul>

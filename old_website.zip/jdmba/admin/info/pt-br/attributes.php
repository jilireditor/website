<p>Aqui voc&ecirc; pode indicar com quais atributos voc&ecirc; quer que as pessoas entrem para se inscreverem nas listas.
<br />Atributos s&atilde;o "globais", por exemplo, se aplicam a todas as listas.</p>
<p><a href="#new">Adicionar novo</a></p>

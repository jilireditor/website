<h1>Esta p&aacute;gina mostra uma breve lista de controle de configura&ccedil;&otilde;es para que o sistema <?php echo NAME?> funcione corretamente</h1>


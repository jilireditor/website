<p>Aqui voc&ecirc; pode especificar os dados corretos do seu site.<br/>
Voc&ecirc; pode usar certos <b>Marcadores</b> para os seus dados.
Os marcadores s&atilde;o apresentados assim <b>[ALGUMTEXTO]</b>, onde <i>ALGUMTEXTO</i> pode variar.
Alguns marcadores muito &uacute;teis s&atilde;o:
<ul>
<li>WEBSITE - endere&ccedil;o do seu site
<li>DOMAIN - nome do seu dom&iacute;nio
<li>SUBSCRIBEURL - endere&ccedil;o da p&aacute;gina de inscri&ccedil;&atilde;o
<li>UNSUBSCRIBEURL - endere&ccedil;o da p&aacute;gina de cancelamento da inscri&ccedil;&atilde;o
<li>PREFERENCESURL - endere&ccedil;o da p&aacute;gina na qual os usu&aacute;rios podem atualizar seus dados
<li>CONFIRMATIONURL - endere&ccedil;o da p&aacute;gina na qual os usu&aacute;rios confirmam a sua inscri&ccedil;&atilde;o
</ul>
<!--Para cabe&ccedil;&aacute;rios e rodap&eacute;s voc&ecirc; pode usar os seguintes c&oacute;digos para incluir documentos externos:
<br/>
<b>[URL:&lt;URL completo da p&aacute;gina a ser carregada&gt;]</b>-->
</p>

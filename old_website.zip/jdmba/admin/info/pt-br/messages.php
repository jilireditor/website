Voc&ecirc; pode usar o "Realinhamento" para reenviar uma mensagem. Assim a mensagem ser&aacute; enviada para os usu&aacute;rios que se inscreveram depois que voc&ecirc; enviou a mensagem. Ela n&atilde;o ser&aacute; reenviada para os usu&aacute;rios que j&aacute; a receberam.<p>Se voc&ecirc; v&ecirc; a mensagem, voc&ecirc; poder&aacute; reenvi&aacute;-la para uma outra lista</p>
<?php if (TEST) { ?>
<br /><b>Aten&ccedil;&atilde;o:</b> Voc&ecirc; est&aacute; operando no modo teste, logo as mensagens ser&atilde;o "reenviadas" para os usu&uacute;rios que j&aacute; a haviam recebido.
<?php } ?>

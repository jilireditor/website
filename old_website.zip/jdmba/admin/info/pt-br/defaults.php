<h1>Adiciona alguns atributos que possam ser &uacute;teis</h1>
Escolha os atributos que voc&ecirc; quer adicionar ao seu sistema de lista de discuss&atilde;o:

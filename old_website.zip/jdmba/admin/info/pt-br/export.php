Voc&ecirc; pode exportar usu&aacute;rios de acordo com a data.<br/>
Se voc&ecirc; clicar no bot&atilde;o "Exportar", surgir&aacute; uma nova janela para baixar o arquivo. Este &eacute; um arquivo de texto com marca&ccedil;&otilde;&otilde;es TAB, contendo o resultado do seu pedido de exporta&ccedil;&atilde;o.<br/>
Voc&ecirc; pode usar este arquivo na maioria dos aplicativos de planilha eletr&ocirc;nica.


<p>Estas p&aacute;ginas servem para o gerenciamento de usu&aacute;rios. Voc&ecirc; pode listar e encontrar, importar e exportar usu&aacute;rios ou ainda corrigir a base de dados de usu&aacute;rios encontrando entradas inv&aacute;lidas.</p>
<p>Para ver os usu&aacute;rios que est&atilde;o em uma lista, v&aacute; at&eacute; a lista e clique "ver membros"</p>

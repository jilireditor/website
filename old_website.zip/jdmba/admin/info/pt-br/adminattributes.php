<p>Aqui voc&ecirc; pode indicar com quais atributos voc&ecirc; quer que os administradores entrem e que podem ser inclu&iacute;dos nos emails que eles mandam para as suas lista(s).
</p>
<p><a href="#new">Adicionar novo</a></p>

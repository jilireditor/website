<p>Hier k&ouml;nnen Attribute f&uuml;r Abonnentenkonten definiert werden.
Diese Attribute sind global, d.h. sie gelten f&uuml;r alle Abonnenten (nicht nur f&uuml;r Abonnenten einer einzelnen Liste)
und sind f&uuml;r alle Administratoren im System gleichmassen zug&auml;nglich (nicht nur f&uuml;r denjenigen Administrator, der das Attribut definiert hat).</p>
<p><a href="#new">Neues Attribut</a></p>

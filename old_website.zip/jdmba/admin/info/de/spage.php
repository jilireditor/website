<p>An dieser Stelle k&ouml;nnen Sie Seiten erstellen, welche von den Abonnenten benutzt werden, um sich f&uuml;r Ihre Listen anzumelden.</p>

<p>Sie k&ouml;nnen hierzu eine beliebige Auswahl aus den Attributen und Listen treffen, welche in Ihrem System definiert sind.
Die Attributwerte entsprechen den globalen Attributwerten, aber Sie k&ouml;nnen die Attribute anders anordnen und andere Standardwerte definieren.
Sie k&ouml;nnen ausserdem festlegen, um ein Attribut auf dieser Anmeldeseite ein Pflichtfeld darstellt oder nicht.</p>

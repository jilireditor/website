<br />Bitten beachten Sie: Wenn Sie hier einen Abonnenten l&ouml;schen, dann wird er lediglich von der betreffenden Liste entfernt.
Die Adresse und allf&auml;llige Attributwerte des Abonnenten bleiben hingegen erhalten.
Um einen Abonnenten vollst&auml;ndig zu l&ouml;schen benutzen Sie bitte die <?php echo PageLink2("users","Abonnentenverwaltung");?>.
<br /><br />


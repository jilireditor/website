<p>Hier k�nnen Sie eine einzelne Seite erstellen bzw. bearbeiten, welche von den Abonnenten benutzt wird, um sich f�r Ihre Listen anzumelden.</p>

<p>Sie k&ouml;nnen eine beliebige Auswahl aus den Attributen und Listen treffen, welche in Ihrem System definiert sind.
Wenn ein Attribut oder eine Liste hier nicht aufgef&uuml;hrt wird, m&uuml;ssen Sie das gew&uuml;nschte Attribut bzw. die gew&uuml;nschte Liste zuerst erstellen.
Die Attributwerte entsprechen den globalen Attributwerten, aber Sie k&ouml;nnen die Attribute anders anordnen und andere Standardwerte definieren.
Sie k&ouml;nnen ausserdem festlegen, um ein Attribut auf dieser Anmeldeseite ein Pflichtfeld darstellt oder nicht.</p>

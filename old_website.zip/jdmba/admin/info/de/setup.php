<p>Diese einfache Checkliste zeigt, welche Schritte erforderlich sind, um PHPlist zu installieren und zu konfigurieren, damit das System korrekt funktioniert.</p>

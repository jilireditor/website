<p>Aqu&iacute; puede identificar los atributos que quiere que los
usuarios introduzcan para inscribirse a las listas.
<br />Los atributos son &#171;globales&#187;, es decir, se aplican a
todas las listas.</p>
<p><a href="#new">A&ntilde;adir uno</a></p>

Aqu&iacute; puede a&ntilde;adir m&uacute;ltiples emails a sus
listas. Todos los emails deben tener los mismos atributos, que se
pueden ver m&aacute;s abajo.

<br />&#171;Eliminar&#187; solamente sacar&aacute; a esta persona de
esta lista
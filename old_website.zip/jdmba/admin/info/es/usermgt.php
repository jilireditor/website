
<p>Estas son funciones relativas a la gesti&oacute;n de
usuarios. Puede enumerar y buscar usuarios, importar y exportar
usuarios, o conciliar la base de datos de usuarios para encontrar las
entradas no v&aacute;lidas.</p>
<p>Para ver qu&eacute; usuarios est&aacute;n en cierta lista vaya a
esa lista y haga click en &#171;ver miembros&#187;</p>

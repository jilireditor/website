<p><h1>This page allows you to clean up the database of users</h1></p>

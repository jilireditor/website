You can export users based on date.<br/>
If you click the "Export" button, you will get a popup box to download a file. This will be a
TAB delimited text file containing the results of your export query.<br/>
You can use this file in most spreadsheet applications.
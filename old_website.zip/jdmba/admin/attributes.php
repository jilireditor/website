<?php
require_once dirname(__FILE__).'/accesscheck.php';
include "commonlib/pages/attributes.php";
?>

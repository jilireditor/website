<?php
include dirname(__FILE__).'/structure.php';
require dirname(__FILE__)."/commonlib/pages/dbcheck.php";
?>

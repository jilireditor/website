This option allows you to have the system automatically create a new message
that is an exact copy of the current message, defined by the interval you specify.
If you use this option, it is important to use the "embargo" option as well, otherwise
your message will be sent constantly, causing flooding of your users with
a lot of messages that are exactly the same.


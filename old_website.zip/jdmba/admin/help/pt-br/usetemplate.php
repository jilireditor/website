<p>Se voc&ecirc; usa um modelo essa mensagem ser&aacute; inserida na parte em que haja o marcador [CONTENT] no seu modelo.</p>
<p>Al&eacutem de [CONTENT], voc&ecirc; pode utiliar [FOOTER] e [SIGNATURE] que servem respectivamente para inserir uma nota de rodap&eacute; e uma assinatura na mensagem, mas ambos s&atilde;o opcionais.</p>

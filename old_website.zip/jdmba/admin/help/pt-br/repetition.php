Esta op&ccedil;&atilde;o permite que o sistema crie c&oacute;pias exatas da mensagem atual, em intervalos que s&atilde;o definidos por voc&ecirc;.
Se voc&ecirc; utilizar essa op&ccedil;&atilde;o &eacute; importante tamb&eacute;m usar a op&ccedil;&atilde;o "veto tempor&aacute;rio", sen&atilde;o suas mensagens ser&atilde;o enviadas repetidas vezes, enchendo a caixa de seus usu&aacute;rios com exatamente a mesma mensagem.


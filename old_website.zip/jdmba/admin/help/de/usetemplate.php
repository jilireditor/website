<p>Falls Sie ein Template benutzen, wird der Nachrichtentext an der Position des [CONTENT]-Platzhalters im Template eingef&uuml;gt.</p>

<p>Nebst [CONTENT] k&ouml;nnen Sie auch die Platzhalter [FOOTER] und [SIGNATURE] benutzen,
welche entsprechend die Fusszeile und die Grusszeile in die Nachricht einf&uuml;gen;
diese beiden Platzhalter sind allerdings optional.</p>

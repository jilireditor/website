<p>Die Option "Nachricht wiederholen" bewirkt, dass das System nach dem Versand einer Nachricht automatisch eine neue Nachricht anlegt,
welche eine exakte Kopie der ersten Nachricht darstellt.
Dies wiederholt sich im angegebenen Intervall so lange, bis der definierte Endtermin erreicht ist.</p>

<p><b>Bitte beachten Sie:</b> Wenn Sie diese Option benutzen ist es sehr wichtig, dass Sie auch eine Sperrfrist setzen.
Andernfalls wird die Nachricht andauernd verschickt und Sie &uuml;berschwemmen Ihre Abonnenten mit unz&auml;hligen identischen Nachrichten.</p>


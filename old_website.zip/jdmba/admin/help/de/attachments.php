<p>Die maximale Anzahl der Anh&auml;nge pro Nachricht wird in der Datei config.php durch den Systembetreiber definiert.</p>

<p><b>Bitte beachten Sie:</b> Bei HTML-Mails werden Anh&auml;nge integriert; bei Text-Mails wird hingegen lediglich ein Link auf die Website eingef&uuml;gt.</p>

<p>Das Feld "Beschreibung des Anhangs" wird nur f&uuml;r E-Mails im Textformat benutzt.</p>
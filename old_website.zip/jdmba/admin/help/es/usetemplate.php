<p>Si utiliza un patr&oacute;n, este mensaje aparecer&aacute; en el lugar indicado por el marcador [CONTENT] del patr&oacute;n.</p>
<p>Adem&aacute;s de [CONTENT] puede incluir [FOOTER] y [SIGNATURE] para incluir un pie de mensaje y una firma respectivamente. Esto es opcional.</p>

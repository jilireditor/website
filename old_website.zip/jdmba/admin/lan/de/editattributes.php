<?php 
$lan = array(
  "NoAttr" => "Kein solches Attribut",
  "AddNew" => "Neues anlegen",
  "SureToDeleteAll" => "Sind Sie sicher dass Sie allen Datens&auml;tze l&ouml;schen wollen?",
  "DelAll" => "Alle l&ouml;schen",
  "ReplaceAllWith" => "Sie k&ouml;nnen auch alle Werte mit einem neuen ersetzen:",
  "ReplaceWith" => "Ersetzen mit",
  "TooManyToList" => "* Zu viele um sie anzuzeigen, Anzahl Abh&auml;ngigkeiten:",
  "TooManyErrors" => "* Zu viele Fehler. Abbruch.",
  "Delete" => "L&ouml;schen",
  "Default" => "(default)",
  "changeorder" => "Reihenfolge &auml;ndern",
  "cannotdelete" => "Kann nicht l&ouml;schen ",
  "dependentrecords" => "Die folgenden Datens&auml;tze h&auml;ngen von diesem Wert ab:<br />
    Aktualisieren Sie zuerst diese Datens&auml;tze, so dass sie diesen Attributwert nicht mehr benutzen, und versuchen Sie es anschliessend nochmals.",
  "addnew" => "Neues anlegen",
  "oneperline" => "1 pro Zeile",
  "deleteandreplace" => 'L&ouml;schen und ersetzen',
);
?>
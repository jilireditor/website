<?php

$lan = array(
  'Developers' => 'Entwicklung',
  'Contributors' => 'Beitr&auml;ge',
  'Translations' => '&Uuml;bersetzung',
  'Portions of the system include' => 'Teile dieses Systems basieren auf',
  'thankseveryone' => 'Die Entwickler danken den zahlreichen Personen,
  	welche zu diesem System beigetragen haben durch ihre Fehlermeldungen, Verbesserungsvorschl&auml;ge,
	Spenden, Ausbauw&uuml;nsche, Sponsoring, &Uuml;bersetzungen und vieles andere.',
  # use this tag to give your own name(s), so you are listed in the "About" page
  # for credits for this particular translation
  'credits for this translation' => 'Martin Sauter',
  # added for German translation
  'Documentation' => 'Dokumentation',
);

?>
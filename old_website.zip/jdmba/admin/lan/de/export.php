<?php
$lan = array(
  "Export" => "Exportieren", // Button
  "ExportOnList" => "PHPList Export der Liste %s von %s bis %s (%s).csv",
  "ExportFromval" => "PHPList Export von %s bis %s (%s).csv",
  "ListMembership" => "Mitgliedschaft anzeigen",
  "ExportOn" => "<h2>Benutzerexport von %s</h2>",
  "DateFrom" => "Von",
  "DateTo" => "Bis",
  "DateToUsed" => "",
  "WhenSignedUp" => "Datum der Anmeldung",
  "WhenRecordChanged" => "Datum der letzten &Auml;nderung",
  "SelectColToIn" => "<h2>Zu exportierende Spalten</h2>",
  # new in 2.10.1
  'When they subscribed to' => 'Datum des Abonnements f&uuml;r Liste ',
);
?>
<?php
$lan = array(
 'You do not have enough priviliges to view this page' => 'Sie haben keine Zugriffsberechtigung f&uuml;r diese Seite.',
 'Members of this list' => 'Abonnenten dieser Liste',
 'Record Saved' => 'Datensatz gespeichert.',
 'List name' => 'Listenname',
 'Check this box to make this list active (listed)' => 'Liste ist aktiv',
 'Order for listing' => 'Reihenfolge der Auflistung',
 'Subject Prefix' => 'Pr&auml;fix f&uuml;r Betreff ',
 'Owner' => 'Eigent&uuml;mer',
 'RSS Source' => 'RSS Source',
 'List Description' => 'Listenbeschreibung',
 'View Items' => 'Objekte anzeigen',
 'Save' => 'Speichern',
 'validate' => 'Validieren',
);
?>

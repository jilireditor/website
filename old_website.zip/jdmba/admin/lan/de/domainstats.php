<?php

$lan = array(
  'Top 50 domains with more than 5 emails' => 'Top 50 Domains mit mehr als 5 E-Mails',
  'num' => 'num',
);
?>
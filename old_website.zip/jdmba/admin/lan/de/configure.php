<?php
$lan = array( 
 'checklist for installation' => 'Checkliste f&uuml;r die Installation',
 'cannot be empty' => 'Darf nicht leer sein',
 'editing' => 'Bearbeitung',
 'save changes' => 'Speichern',
 'edit' => 'Bearbeiten'
);
?>
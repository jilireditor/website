<?php

$lan = array(
  'Updating the regular expression of this rule caused an Sql conflict<br/>
  	This is probably because there is already a rule like that.
	Do you want to delete this rule instead?' =>
	'Die Aktualisierung der Regular Expression dieser Regel hat einen SQL-Konflikt verursacht.<br/>
	Wahrscheinlich existiert bereits eine solche Regel.
	Wollen Sie diese Regel stattdessen l&ouml;schen?',
  'Yes' => 'Ja',
  'No' => 'Nein',
  'back to list of bounce rules' => 'Zur&uuml;ck zur Liste der Regeln f&uuml;r unzustellbare Mails',
  'Regular Expression' => 'Regular Expression',
  'Created By' => 'Angelegt von',
  'Action' => 'Massnahme',
  'Status' => 'Status',
  'Select Status' => 'Status w&auml;hlen',
  'Memo for this rule' => 'Kommentar zu dieser Regel',
  'Save Changes' => 'Speichern',
  'related bounces' => 'Zugeh&ouml;rige unzustellbare Mail',
  'no related bounces found' => 'Es wurden keine zugeh&ouml;rigen unzustellbaren Mails gefunden.',
  'and more, %d in total' => 'und weitere, total %d',
);

?>

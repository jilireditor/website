<?php

$lan = array(
  'Process Next Batch' => 'N&auml;chsten Auftrag verarbeiten',
  'Process Killed by other process' => 'Der Prozess wurde durch einen anderen Prozess abgebrochen',
  'Hmm, duplicate entry, ' => 'Doppelter Eintrag, ',
  'new rules found' => 'Es wurden neue Regeln gefunden',
  'bounces not matched' => 'Retouren wurden nicht gematched',
  'bounces matched to existing rules' => 'Retouren entsprachen bestehenden Regeln',
);

?>

<?php

$lan = array(
'Message Click Statistics' => 'Klick-Statistik der Nachricht',
'firstclick' => 'firstclick',
'latestclick' => 'latestclick',
'clicks' => 'Klicks',
'Click Details for a Message' => 'Klick-Details der Nachricht',
'Subject' => 'Betreff',
'Entered' => 'Eingegeben',
'sent' => 'Gesendet',
'clickrate' => 'Klickrate',
'unique clicks' => 'Unique Clicks',
'unique clickrate' => 'Unique Clickrate',
'who' => 'wer',
'view users' => 'Abonnenten anzeigen',
'Select Message to view' => 'Nachricht ausw&auml;hlen',
'Available Messages' => 'Verf&uuml;gbare Nachrichten',
'You do not have access to this page' => 'Sie haben keine Zugriffsberechtigung f&uuml;r diese Seite.',
);
?>
<?php

$lan = array(
'Add new admin' => 'Neuer Administrator',
'Administrators' => 'Administratoren',
'Find an admin' => 'Administrator suchen',
'Administrators' => 'Administratoren',
'Show' => 'Zeigen',
'Show' => 'Zeigen',
'Show' => 'Zeigen',
'Add new admin' => 'Neuer Administrator',
'Import list of admins' => 'Administratoren importieren',
'Deleting' => 'L&ouml;sche Administrator ID',
'Done' => 'Erledigt',
'Admin added' => 'Administrator hinzugef&uuml;gt',
'Listing admin' => 'Liste der Administratoren',
'Listing admin 1 to 50' => 'Liste der Administratoren (1 bis 50)',
'found' => 'gefunden',

);

?>
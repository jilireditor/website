<?php
$lan = array(
 'This page can only be called from the commandline' => 'Diese Seite kann nur von der Kommandozeile aus aufgerufen werden.',
 'Getting and Parsing the RSS sources' => 'Hole und parse die RSS-Feeds',
 'Rss Errors' => 'RSS-Fehler',
 'Rss Results' => 'RSS-Resultate',
 'Rss Failure report' => 'RSS-Fehlerbericht',
 'Parsing' => 'Parse RSS-Feed',
 'ok' => 'OK',
 'failed' => 'Import fehlgeschlagen',
 'Process Killed by other process' => 'Der Prozess wurde durch einen anderen Prozess abgebrochen',
 'items' => 'Objekte',
 'new items' => 'Neue Objekte',
'Nothing to do' => 'Keine Aufgaben',
);
?>

<?php
$lan = array(
 'Deleting' => 'L&ouml;sche',
 'Done' => 'Abgeschlossen',
 'events' => 'Events',
 'Listing' => 'Liste',
 'to' => 'bis',
 'Listing 1 to 50' => 'Zeige 1 bis 50',
 'Are you sure you want to delete all events older than 2 months?' =>
 	'Sind Sie sicher, dass Sie alle Events l&ouml;schen wollen, die &auml;lter als 2 Monate sind?',
 'Delete all (&gt; 2 months old)' => 'Alle l&ouml;schen (&gt; 2 Monate alt)',
 'Are you sure you want to delete all events matching this filter?' =>
 	'Sind Sie sicher, dass Sie alle Events l&ouml;schen wollen, welche diesem Filter entsprechen?',
 'Delete all' => 'Alle l&ouml;schen',
 'No events available' => 'No events available',
 'Filter' => 'Filter',
 'Exclude filter' => 'ausschliessen',
 'del' => 'L&ouml;schen', # as in short for delete
 'date' => 'Datum',
 'message' => 'Nachricht', 
 'events' => 'Events',
 'page' => 'Seite',
);
?>

<?php

$lan = array(
  'Process Next %d' => 'Bearbeite n&auml;chste %d',
  'No match' => 'Keine &Uuml;bereinstimmung',
  'bounces did not match any current active rule' => 'unzustellbare Mails stimmten mit keiner der aktiven Regeln &uuml;berein',
  'bounce matched current active rules' => 'unzustellbare Mails stimmten mit einer aktiven Regel &uuml;berein',
);
?>

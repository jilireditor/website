<?php 
$lan = array(
  "loading" => "Lade",
  "done" => "Abgeschlossen",
  "name_empty" => "Der Name darf nicht leer sein:",
  "name_not_unique" => "Der Name ist nicht eindeutig genug",
  "continue" => "Weiter",
  'add' => 'Hinzuf&uuml;gen',
);
?>
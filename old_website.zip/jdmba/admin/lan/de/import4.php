<?php
$lan = array(

  'add_list' => 'Liste hinzuf&uuml;gen', //duplicated in import1_text
  'cant_connect' => 'Verbindung zur Datenbank konnte nicht hergestellt werden',
  'no_users_to_copy' => 'Es gibt keine Benutzer, die kopiert werden k&ouml;nnten. Ist das Pr&auml;fix korrekt?',
  'remote_server' => '<b>Angaben zur Datenbank</b>',
  'server' => 'Server',
  'user' => 'Benutzername',
  'passwd' => 'Passwort',
  'database' => 'Name der Datenbank',
  'table_prefix' => 'Tabellen-Pr&auml;fix',
  'usertable_prefix' => 'Pr&auml;fix der Benutzertabelle',
  'select_lists' => '<br /><b>Listen, zu denen die E-Mail-Adressen hinzugef&uuml;gt werden sollen</b>',
  'copy_lists' => 'Kopiere die Listen aus der Datenbank (Identifikation erfolgt &uuml;ber den Namen)',
  'users_as_html' => 'Neue Benutzer als HTML markieren',
  'info_overwrite_existing' =>
  	'Wenn Sie "Bestehende &uuml;berschreiben" w&auml;hlen, werden bestehende Benutzerdaten durch die importierten Daten ersetzt.
	Benutzer werden &uuml;ber die E-Mail-Adresse identifiziert.',
  'overwrite_existing' => 'Bestehende &uuml;berschreiben',
  'connecting_remote' => 'Verbindung zur Datenbank wird hergestellt',
  'getting_data' => 'Empfange Daten von ',
  'remote_version' => 'Remote version is',
  'remote_has' => 'Remote version has',
  'users' => 'Benutzer',
  'lists' => 'Listen',
  'copying_lists' => 'Kopiere Listen',
  'list' => 'Liste',
  'exists_locally' => 'Existiert lokal',
  'created_locally' => 'Wurde lokal erzeugt',
  'remote_list' => 'Zu importierende Liste',
  'not_created' => 'Nicht angelegt',
  'copying_attribs' => 'Kopiere Attribute',
  'attrib' => 'Attribut',
  'copying_users' => 'Kopiere Benutzer',
  'overwrite_local' => '&Uuml;berschreibe lokale Daten',
  'keep_local' => 'Lokale Daten bleiben erhalten',
  'new_user' => 'ist an neuer Benutzer',
  'no_mapped_attrib' => 'Fehler: Es wurde kein Attribut zugewiesen f&uuml;r',
  'no_local_list' => 'Fehler: Es wurde keine lokale Liste definiert f&uuml;r',
  'No lists available' => 'Es sind keine Listen vorhanden',
  'Done' => 'Erledigt',
  'new users' => 'Neue Benutzer',
  'and' => 'und',
  'existing users' => 'Bestehende Benutzer',
  'continue' => 'Weiter',

);
?>
<?php

$lan = array(
  'PHPList Users' => 'PHPList Benutzer',
  'on' => 'von', # as in Member of a list (user A on list B)
  'List Membership' => 'Mitgliedschaft auflisten',
  'No Lists' => 'Keine Listen',
);

?>
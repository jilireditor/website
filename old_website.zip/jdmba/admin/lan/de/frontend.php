<?php

$lan = array(
  'Please indicate how often you want to receive messages' =>
  	'Bitte geben Sie an, wie h&auml;ufig Sie Nachrichten erhalten wollen',
  'Email is blacklisted, so request for confirmation has been sent.' =>
  	'Der Benutzer steht auf der Blacklist, deshalb wurde eine Best&auml;tigungsanfrage verschickt.',
  'If user confirms subscription, they will be removed from the blacklist.' =>
  	'Wenn die Benutzer das Abonnement best&auml;tigen, werden Sie von der Blacklist entfernt.',
//  'YouAreBlacklisted' =>
//  	'Ihre E-Mail-Adresse steht auf unserer Blacklist. Dies bedeutet, dass Sie uns gebeten haben, Ihnen nie mehr irgendwelche Newsletters zu schicken.<br/>
//	Das einzige Mail, das unser System verschicken wird, ist eine Best&auml;tigungsanfrage.
//	Nur wenn Sie den Link in dieser Mail anklicken, werden Sie von unserer Blacklist entfernt und erhalten in Zukunft wieder unsere Newsletters.'
);

?>
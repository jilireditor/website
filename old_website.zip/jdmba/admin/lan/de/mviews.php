<?php

$lan = array(
  'You do not have access to this page' => 'Sie haben keine Zugriffsberechtigung f&uuml;r diese Seite.',
  'Select Message to view' => 'Nachricht ausw&auml;hlen',
  'Available Messages' => 'Verf&uuml;gbare Nachrichten',
  'views' => 'Ge&ouml;ffnet (Views)',
  'rate' => 'Rate',
  'View Details for a Message' => 'Details einer Nachricht anzeigen',
  'Subject' => 'Betreff',
  'Entered' => 'Erfasst',
  'Message Open Statistics' => 'Statistik der ge&ouml;ffneten Nachrichten',
  'Listing user %d to %d' => 'Zeige Empf&auml;nger %d to %d',
  'Entries' => 'Eintr&auml;ge',
  'firstview' => 'Erster View',
  'lastview' => 'Letzter View',
  'views' => 'Views',
  'responsetime' => 'Antwortzeit',
  'sec' => 'Sek.',
);

?>
